import os
from datetime import timedelta

class Config:
    """Application configuration settings"""
    
    # Basic Flask Configuration
    SECRET_KEY = os.environ.get('SECRET_KEY') or 'chus-ekari-100-ton-secret-key-2025'
    DEBUG = True
    
    # File Upload Settings
    MAX_CONTENT_LENGTH = 16 * 1024 * 1024  # 16MB max file size
    UPLOAD_FOLDER = 'uploads'
    ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'gif', 'bmp'}
    
    # Model Configuration
    MODEL_PATH = os.path.join('models', 'Final_Model.keras')
    CLASS_MAPPING_PATH = os.path.join('models', 'class_mapping.json')
    DISEASE_SOLUTIONS_PATH = os.path.join('models', 'disease_solutions.json')
    
    # Image Processing
    IMAGE_SIZE = 224  # Model input size (we'll adjust based on your model)
    IMAGE_CHANNELS = 3
    
    # Application Settings
    APP_NAME = 'ऊस एकरी १०० टन'
    COMPANY_NAME = 'Chordz Technologies'
    VERSION = '1.0.0'
    
    # Logging Configuration
    LOG_LEVEL = 'INFO'
    LOG_FILE = os.path.join('logs', 'app.log')
    
    # Cache Settings
    CACHE_TIMEOUT = 300  # 5 minutes
    
    # Language Settings
    DEFAULT_LANGUAGE = 'marathi'
    SUPPORTED_LANGUAGES = ['marathi', 'english']

class DevelopmentConfig(Config):
    """Development configuration"""
    DEBUG = True
    TESTING = False

class ProductionConfig(Config):
    """Production configuration"""
    DEBUG = False
    TESTING = False
    
    # Production-specific settings
    SECRET_KEY = os.environ.get('SECRET_KEY') or 'change-this-in-production'
    LOG_LEVEL = 'WARNING'

class TestingConfig(Config):
    """Testing configuration"""
    TESTING = True
    DEBUG = True
    
    # Test-specific paths
    MODEL_PATH = os.path.join('tests', 'test_model.keras')

# Configuration dictionary
config = {
    'development': DevelopmentConfig,
    'production': ProductionConfig,
    'testing': TestingConfig,
    'default': DevelopmentConfig
}
