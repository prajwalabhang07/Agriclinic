"""
Application Factory for Flask App
Creates and configures the Flask application instance
"""

import os
import logging
from flask import Flask
from config import config

def create_app(config_name='default'):
    """Create Flask application with specified configuration"""
    
    # Create Flask instance
    app = Flask(__name__)
    
    # Load configuration
    app.config.from_object(config[config_name])
    
    # Setup logging
    setup_logging(app)
    
    # Create upload directory if it doesn't exist
    upload_dir = app.config.get('UPLOAD_FOLDER', 'uploads')
    if not os.path.exists(upload_dir):
        os.makedirs(upload_dir)
    
    # Create logs directory if it doesn't exist  
    log_dir = 'logs'
    if not os.path.exists(log_dir):
        os.makedirs(log_dir)
    
    # Register blueprints (routes)
    from app.routes import main_bp
    app.register_blueprint(main_bp)
    
    # Initialize model and data (we'll add this in next step)
    with app.app_context():
        from app.models import initialize_model_and_data
        initialize_model_and_data()
    
    app.logger.info(f"🌾 {app.config['APP_NAME']} initialized successfully")
    app.logger.info(f"🏢 Company: {app.config['COMPANY_NAME']}")
    app.logger.info(f"📊 Version: {app.config['VERSION']}")
    
    return app

def setup_logging(app):
    """Configure application logging"""
    
    log_level = getattr(logging, app.config.get('LOG_LEVEL', 'INFO'))
    log_file = app.config.get('LOG_FILE', 'logs/app.log')
    
    # Create formatter
    formatter = logging.Formatter(
        '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )
    
    # File handler
    if not os.path.exists(os.path.dirname(log_file)):
        os.makedirs(os.path.dirname(log_file))
    
    file_handler = logging.FileHandler(log_file)
    file_handler.setLevel(log_level)
    file_handler.setFormatter(formatter)
    
    # Console handler
    console_handler = logging.StreamHandler()
    console_handler.setLevel(log_level)
    console_handler.setFormatter(formatter)
    
    # Configure app logger
    app.logger.setLevel(log_level)
    app.logger.addHandler(file_handler)
    
    if app.config['DEBUG']:
        app.logger.addHandler(console_handler)
