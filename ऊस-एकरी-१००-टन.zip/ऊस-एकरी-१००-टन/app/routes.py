"""
API Routes for Sugarcane Disease Detection System
Professional endpoints with farmer-friendly responses in Marathi
"""

import logging
import os
from datetime import datetime
from flask import Blueprint, render_template, request, jsonify, current_app, flash
from werkzeug.utils import secure_filename
from utils.model_loader import get_model_loader
from utils.image_processor import get_image_processor
from utils.disease_analyzer import get_disease_analyzer
from utils.response_formatter import format_farmer_response, format_error_response

logger = logging.getLogger(__name__)

# Create Blueprint for routes
main_bp = Blueprint('main', __name__)

def allowed_file(filename):
    """Check if uploaded file is allowed"""
    return '.' in filename and \
           filename.rsplit('.', 1)[1].lower() in current_app.config['ALLOWED_EXTENSIONS']

@main_bp.route('/')
def home():
    """Main application page - Farmer-friendly interface"""
    try:
        logger.info("🏠 मुख्य पेज लोड करत आहे...")
        
        # Get system status for display
        model_loader = get_model_loader(current_app.config)
        system_status = {
            'app_name': current_app.config['APP_NAME'],
            'company_name': current_app.config['COMPANY_NAME'],
            'version': current_app.config['VERSION'],
            'model_ready': model_loader.model is not None if model_loader else False,
            'total_diseases': len(model_loader.classes) if model_loader and model_loader.classes else 0,
            'status_marathi': 'तयार' if model_loader and model_loader.model else 'लोडिंग...'
        }
        
        return render_template('index.html', system=system_status)
        
    except Exception as e:
        logger.error(f"❌ मुख्य पेज त्रुटी: {str(e)}")
        flash(f'पेज लोडिंगमध्ये समस्या: {str(e)}', 'error')
        return render_template('error.html', error="मुख्य पेज लोड करता आले नाही")

@main_bp.route('/api/health')
def health_check():
    """System health check endpoint"""
    try:
        model_loader = get_model_loader(current_app.config)
        image_processor = get_image_processor(current_app.config)
        
        health_status = {
            'status': 'healthy',
            'timestamp': datetime.now().isoformat(),
            'app_info': {
                'name': current_app.config['APP_NAME'],
                'company': current_app.config['COMPANY_NAME'],
                'version': current_app.config['VERSION'],
                'environment': 'development' if current_app.debug else 'production'
            },
            'system_status': {
                'model_loaded': model_loader.model is not None if model_loader else False,
                'image_processor_ready': image_processor is not None,
                'diseases_available': len(model_loader.classes) if model_loader else 0,
                'solutions_loaded': len(model_loader.disease_solutions) if model_loader else 0
            },
            'capabilities': {
                'image_formats': list(current_app.config['ALLOWED_EXTENSIONS']),
                'max_file_size_mb': current_app.config['MAX_CONTENT_LENGTH'] // (1024 * 1024),
                'languages': ['marathi', 'english'],
                'features': ['disease_detection', 'treatment_advice', 'cost_estimation']
            },
            'status_marathi': 'प्रणाली तयार आहे' if model_loader and model_loader.model else 'प्रणाली लोड होत आहे'
        }
        
        status_code = 200 if health_status['system_status']['model_loaded'] else 503
        
        return jsonify(health_status), status_code
        
    except Exception as e:
        logger.error(f"❌ आरोग्य तपासणी त्रुटी: {str(e)}")
        return jsonify({
            'status': 'unhealthy',
            'error': str(e),
            'error_marathi': f'प्रणाली तपासणीत त्रुटी: {str(e)}',
            'timestamp': datetime.now().isoformat()
        }), 500

@main_bp.route('/api/predict', methods=['POST'])
def predict_disease():
    """
    Main disease prediction endpoint
    Handles image upload and returns comprehensive analysis
    """
    try:
        logger.info("🔬 नवीन रोग निदान विनंती...")
        
        # Validate system readiness
        model_loader = get_model_loader(current_app.config)
        if not model_loader or not model_loader.model:
            return format_error_response(
                'AI प्रणाली तयार नाही, कृपया थोडा वेळ थांबा',
                'AI system not ready, please wait',
                503
            )
        
        # Validate file upload
        if 'image' not in request.files:
            return format_error_response(
                'कृपया छायाचित्र निवडा',
                'Please select an image',
                400
            )
        
        file = request.files['image']
        if file.filename == '':
            return format_error_response(
                'कोणतीही फाइल निवडली नाही',
                'No file selected',
                400
            )
        
        if not allowed_file(file.filename):
            return format_error_response(
                f'कृपया फक्त {", ".join(current_app.config["ALLOWED_EXTENSIONS"])} फाइल अपलोड करा',
                f'Please upload only {", ".join(current_app.config["ALLOWED_EXTENSIONS"])} files',
                400
            )
        
        # Get farmer context from request
        farmer_context = {
            'farm_size': float(request.form.get('farm_size', 1.0)),
            'location': request.form.get('location', 'अज्ञात'),
            'crop_stage': request.form.get('crop_stage', 'अज्ञात'),
            'previous_diseases': request.form.get('previous_diseases', ''),
            'farmer_experience': request.form.get('experience', 'मध्यम'),
            'timestamp': datetime.now().isoformat()
        }
        
        logger.info(f"👨‍🌾 शेतकरी संदर्भ: शेत आकार {farmer_context['farm_size']} एकर")
        
        # Process image
        image_processor = get_image_processor(current_app.config)
        processed_image = image_processor.process_image_for_prediction(file)
        
        if processed_image is None:
            return format_error_response(
                'छायाचित्र प्रक्रिया करता आली नाही, कृपया दुसरे छायाचित्र वापरा',
                'Failed to process image, please try another image',
                400
            )
        
        # Perform disease analysis
        disease_analyzer = get_disease_analyzer(model_loader, current_app.config)
        analysis_result = disease_analyzer.analyze_disease(processed_image, farmer_context)
        
        if not analysis_result['success']:
            return format_error_response(
                analysis_result.get('error_marathi', 'रोग ओळखण्यात अयशस्वी'),
                analysis_result.get('error_english', 'Disease detection failed'),
                500
            )
        
        # Log successful prediction
        logger.info(f"✅ यशस्वी निदान: {analysis_result['disease_name_marathi']} ({analysis_result['confidence']}%)")
        
        # Format response for farmer
        formatted_response = format_farmer_response(analysis_result)
        
        return jsonify(formatted_response), 200
        
    except Exception as e:
        logger.error(f"❌ निदान त्रुटी: {str(e)}")
        return format_error_response(
            f'काहीतरी चूक झाली: {str(e)}',
            f'Something went wrong: {str(e)}',
            500
        )

@main_bp.route('/api/disease-info/<disease_name>')
def get_disease_info(disease_name):
    """Get detailed information about a specific disease"""
    try:
        logger.info(f"ℹ️ रोग माहिती विनंती: {disease_name}")
        
        model_loader = get_model_loader(current_app.config)
        if not model_loader:
            return format_error_response(
                'माहिती प्रणाली उपलब्ध नाही',
                'Information system not available',
                503
            )
        
        # Get disease information
        disease_info = model_loader.disease_solutions.get(disease_name, {})
        if not disease_info:
            return format_error_response(
                f'{disease_name} रोगाची माहिती सापडली नाही',
                f'Information for {disease_name} not found',
                404
            )
        
        # Get Marathi name
        marathi_name = model_loader.class_mapping.get('marathinames', {}).get(disease_name, disease_name)
        
        # Format comprehensive disease information
        comprehensive_info = {
            'success': True,
            'disease_name_english': disease_name,
            'disease_name_marathi': marathi_name,
            'detailed_info': {
                'scientific_name': model_loader.class_mapping.get('scientificnames', {}).get(disease_name, 'माहिती नाही'),
                'symptoms': disease_info.get('symptoms', 'लक्षणे उपलब्ध नाहीत'),
                'detailed_symptoms': disease_info.get('detailedsymptoms', []),
                'causes': disease_info.get('causes', 'कारणे अज्ञात'),
                'solution': disease_info.get('solution', 'उपचार माहिती नाही'),
                'prevention': disease_info.get('prevention', 'प्रतिबंधक उपाय नाही'),
                'organic_solutions': disease_info.get('organicsolutions', []),
                'cost_estimate': disease_info.get('costestimate', 'खर्च अज्ञात'),
                'recovery_time': disease_info.get('recoverytime', 'वेळ अज्ञात'),
                'severity_level': disease_info.get('severity', 'मध्यम'),
                'emergency_protocol': disease_info.get('emergencyprotocol', False)
            },
            'farmer_guidance': {
                'difficulty_level': 'सोपे' if disease_name == 'Healthy' else 'मध्यम',
                'success_rate': 'उच्च' if disease_name not in ['RedRot', 'Sett Rot'] else 'मध्यम',
                'monitoring_required': 'दररोज' if disease_name in ['RedRot', 'Sett Rot'] else 'साप्ताहिक'
            }
        }
        
        return jsonify(comprehensive_info), 200
        
    except Exception as e:
        logger.error(f"❌ माहिती त्रुटी: {str(e)}")
        return format_error_response(
            f'माहिती मिळविण्यात त्रुटी: {str(e)}',
            f'Failed to get information: {str(e)}',
            500
        )

@main_bp.route('/api/all-diseases')
def get_all_diseases():
    """Get list of all supported diseases"""
    try:
        logger.info("📋 सर्व रोगांची यादी विनंती...")
        
        model_loader = get_model_loader(current_app.config)
        if not model_loader:
            return format_error_response(
                'रोग डेटाबेस उपलब्ध नाही',
                'Disease database not available',
                503
            )
        
        # Prepare disease list
        diseases_list = []
        for disease_class in model_loader.classes:
            marathi_name = model_loader.class_mapping.get('marathinames', {}).get(disease_class, disease_class)
            disease_info = model_loader.disease_solutions.get(disease_class, {})
            
            diseases_list.append({
                'english_name': disease_class,
                'marathi_name': marathi_name,
                'scientific_name': model_loader.class_mapping.get('scientificnames', {}).get(disease_class, 'अज्ञात'),
                'severity': disease_info.get('severity', 'मध्यम'),
                'common': disease_info.get('common', True),
                'preventable': disease_info.get('preventable', True),
                'treatable': disease_info.get('treatable', True),
                'emergency': disease_info.get('emergencyprotocol', False)
            })
        
        # Sort by severity and commonality
        diseases_list.sort(key=lambda x: (
            0 if x['emergency'] else 1,
            0 if x['common'] else 1,
            x['marathi_name']
        ))
        
        response = {
            'success': True,
            'total_diseases': len(diseases_list),
            'diseases': diseases_list,
            'categories': {
                'emergency': [d for d in diseases_list if d['emergency']],
                'common': [d for d in diseases_list if d['common'] and not d['emergency']],
                'rare': [d for d in diseases_list if not d['common'] and not d['emergency']]
            },
            'statistics': {
                'preventable_count': len([d for d in diseases_list if d['preventable']]),
                'treatable_count': len([d for d in diseases_list if d['treatable']]),
                'emergency_count': len([d for d in diseases_list if d['emergency']])
            }
        }
        
        return jsonify(response), 200
        
    except Exception as e:
        logger.error(f"❌ रोग यादी त्रुटी: {str(e)}")
        return format_error_response(
            f'रोग यादी मिळविण्यात त्रुटी: {str(e)}',
            f'Failed to get disease list: {str(e)}',
            500
        )

@main_bp.route('/api/farmer-support')
def farmer_support():
    """Farmer support information and contacts"""
    try:
        support_info = {
            'success': True,
            'contact_information': {
                'helpline': '1800-XXX-XXXX',
                'whatsapp': '+91-XXXXXXXXXX',
                'email': 'support@chordz.tech',
                'website': 'www.chordz.tech'
            },
            'support_hours': {
                'weekdays': 'सकाळी ९ ते संध्याकाळी ६',
                'weekends': 'सकाळी १० ते दुपारी २',
                'emergency': '२४ तास (गंभीर प्रकरणांसाठी)'
            },
            'available_services': [
                'तांत्रिक सहाय्य',
                'कृषी सल्ला',
                'उत्पादन मार्गदर्शन',
                'बाजार माहिती',
                'योजना सहाय्य'
            ],
            'local_experts': [
                {
                    'name': 'कृषी विकास अधिकारी',
                    'contact': 'जिल्हा कार्यालयाशी संपर्क साधा',
                    'expertise': 'सामान्य कृषी सल्ला'
                },
                {
                    'name': 'प्लांट पॅथॉलॉजिस्ट',
                    'contact': 'कृषी महाविद्यालयाशी संपर्क साधा',
                    'expertise': 'रोग निदान आणि उपचार'
                }
            ],
            'emergency_protocol': {
                'immediate_steps': [
                    'प्रभावित पिकाचे फोटो घ्या',
                    'आजूबाजूची पिके तपासा',
                    'तत्काळ तज्ञांशी संपर्क साधा'
                ],
                'critical_diseases': ['RedRot', 'Sett Rot', 'Grassy shoot'],
                'response_time': '२४ तासांच्या आत'
            }
        }
        
        return jsonify(support_info), 200
        
    except Exception as e:
        logger.error(f"❌ सहाय्य माहिती त्रुटी: {str(e)}")
        return format_error_response(
            'सहाय्य माहिती उपलब्ध नाही',
            'Support information unavailable',
            500
        )

@main_bp.route('/results')
def show_results():
    """Display prediction results page"""
    try:
        # Get result data from query parameters or session
        result_data = request.args.get('data')
        if not result_data:
            flash('परिणाम उपलब्ध नाहीत', 'warning')
            return redirect('/')
        
        return render_template('result.html', result=result_data)
        
    except Exception as e:
        logger.error(f"❌ परिणाम पेज त्रुटी: {str(e)}")
        return render_template('error.html', error="परिणाम दाखवता आले नाही")

@main_bp.errorhandler(404)
def not_found(error):
    """Handle 404 errors"""
    return format_error_response(
        'हे पेज सापडले नाही',
        'Page not found',
        404
    )

@main_bp.errorhandler(413)
def file_too_large(error):
    """Handle file too large errors"""
    max_size = current_app.config['MAX_CONTENT_LENGTH'] // (1024 * 1024)
    return format_error_response(
        f'छायाचित्र खूप मोठे आहे. कृपया {max_size}MB पेक्षा लहान फाइल वापरा',
        f'File too large. Please use files smaller than {max_size}MB',
        413
    )

@main_bp.errorhandler(500)
def internal_server_error(error):
    """Handle internal server errors"""
    logger.error(f"❌ सर्व्हर त्रुटी: {str(error)}")
    return format_error_response(
        'सर्व्हरमध्ये काहीतरी समस्या आली. कृपया पुन्हा प्रयत्न करा',
        'Internal server error. Please try again',
        500
    )
