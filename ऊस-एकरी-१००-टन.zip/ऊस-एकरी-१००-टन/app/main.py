"""
ऊस एकरी १०० टन - Main Application Entry Point
Professional Sugarcane Disease Detection System
Chordz Technologies
"""

import os
import sys
import logging
from pathlib import Path

# Add the project root to Python path
PROJECT_ROOT = Path(__file__).parent.parent
sys.path.insert(0, str(PROJECT_ROOT))

# Now import FastAPI and other modules
from fastapi import FastAPI, Request, HTTPException
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from fastapi.responses import HTMLResponse
from fastapi.middleware.cors import CORSMiddleware
from fastapi.middleware.gzip import GZipMiddleware
import uvicorn

# Import our API routes (we'll create these inline if missing)
try:
    from app.api.routes.prediction import router as prediction_router
    from app.api.routes.health import router as health_router
    from app.api.routes.diseases import router as diseases_router
except ImportError:
    # If routes don't exist, we'll create them inline
    prediction_router = None
    health_router = None
    diseases_router = None

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# Initialize FastAPI app
app = FastAPI(
    title="ऊस एकरी १०० टन",
    description="Professional Sugarcane Disease Detection System for Indian Farmers",
    version="1.0.0",
    docs_url="/docs",
    redoc_url="/redoc"
)

# Add middleware
app.add_middleware(GZipMiddleware, minimum_size=1000)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Create directories if they don't exist
os.makedirs("static", exist_ok=True)
os.makedirs("templates", exist_ok=True)
os.makedirs("models", exist_ok=True)
os.makedirs("data", exist_ok=True)
os.makedirs("logs", exist_ok=True)

# Mount static files
if os.path.exists("static"):
    app.mount("/static", StaticFiles(directory="static"), name="static")

# Setup templates
templates = None
if os.path.exists("templates"):
    templates = Jinja2Templates(directory="templates")

# Simple inline routes (if route files don't exist)
@app.get("/", response_class=HTMLResponse)
async def home(request: Request):
    """Home page"""
    if templates and os.path.exists("templates/index.html"):
        return templates.TemplateResponse("index.html", {"request": request})
    else:
        return HTMLResponse("""
        <!DOCTYPE html>
        <html lang="mr">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>ऊस एकरी १०० टन</title>
            <style>
                body { font-family: Arial, sans-serif; text-align: center; padding: 50px; }
                .container { max-width: 800px; margin: 0 auto; }
                .logo { font-size: 3em; margin-bottom: 20px; }
                .title { font-size: 2em; color: #2E7D32; margin-bottom: 10px; }
                .subtitle { font-size: 1.2em; color: #666; margin-bottom: 30px; }
                .btn { background: #4CAF50; color: white; padding: 15px 30px; text-decoration: none; border-radius: 5px; font-size: 18px; }
                .features { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 20px; margin-top: 40px; }
                .feature { padding: 20px; background: #f5f5f5; border-radius: 10px; }
            </style>
        </head>
        <body>
            <div class="container">
                <div class="logo">🌾</div>
                <h1 class="title">ऊस एकरी १०० टन</h1>
                <p class="subtitle">AI शक्तीयुक्त ऊस रोग निदान सिस्टम</p>
                <p class="subtitle">Chordz Technologies</p>
                
                <a href="/docs" class="btn">API Documentation पहा</a>
                
                <div class="features">
                    <div class="feature">
                        <h3>🤖 AI निदान</h3>
                        <p>अत्याधुनिक मशीन लर्निंग</p>
                    </div>
                    <div class="feature">
                        <h3>📱 मोबाइल फ्रेंडली</h3>
                        <p>सर्व डिव्हाइसवर काम करते</p>
                    </div>
                    <div class="feature">
                        <h3>🌾 शेतकरी केंद्रित</h3>
                        <p>मराठी भाषेत सल्ला</p>
                    </div>
                    <div class="feature">
                        <h3>💰 किफायतशीर</h3>
                        <p>खर्चाचा अंदाज आणि उपचार</p>
                    </div>
                </div>
                
                <div style="margin-top: 40px;">
                    <h3>🔗 Links:</h3>
                    <p><a href="/api/health">Health Check</a> | <a href="/docs">API Docs</a> | <a href="/redoc">ReDoc</a></p>
                </div>
            </div>
        </body>
        </html>
        """)

@app.get("/api/health")
async def health_check():
    """Simple health check"""
    return {
        "status": "healthy",
        "message": "ऊस एकरी १०० टन सिस्टम तयार आहे!",
        "system_status": {
            "model_loaded": os.path.exists("models/sugarcane_disease_model.h5"),
            "data_files": os.path.exists("data"),
            "static_files": os.path.exists("static")
        }
    }

@app.get("/api/all-diseases")
async def get_all_diseases():
    """Get all diseases information"""
    import json
    
    # Try to load from class_mapping.json
    if os.path.exists("data/class_mapping.json"):
        try:
            with open("data/class_mapping.json", "r", encoding="utf-8") as f:
                data = json.load(f)
                diseases = []
                
                for disease_id, info in data.get("class_mapping", {}).items():
                    diseases.append({
                        "id": disease_id,
                        "marathi_name": info.get("marathi_name", "अज्ञात"),
                        "english_name": info.get("english_name", "Unknown"),
                        "scientific_name": info.get("scientific_name", ""),
                        "common": info.get("common", False),
                        "emergency": info.get("emergency", False)
                    })
                
                return {"success": True, "diseases": diseases}
        except Exception as e:
            logger.error(f"Error loading diseases: {e}")
    
    # Fallback data
    return {
        "success": True,
        "diseases": [
            {
                "id": "0",
                "marathi_name": "निरोगी पान",
                "english_name": "Healthy",
                "scientific_name": "Healthy Leaf",
                "common": True,
                "emergency": False
            },
            {
                "id": "1", 
                "marathi_name": "लाल कुजणे",
                "english_name": "RedRot",
                "scientific_name": "Colletotrichum falcatum",
                "common": True,
                "emergency": True
            },
            {
                "id": "2",
                "marathi_name": "तपकिरी ठिपके",
                "english_name": "Brown Spot",
                "scientific_name": "Bipolaris sacchari",
                "common": True,
                "emergency": False
            }
        ]
    }

@app.post("/api/predict")
async def predict_disease(request: Request):
    """Simple prediction endpoint"""
    return {
        "success": True,
        "message": "येथे AI प्रिडिक्शन येईल",
        "diagnosis": {
            "disease_name": "तपकिरी ठिपके",
            "disease_name_english": "Brown Spot", 
            "confidence": 85.5,
            "severity": "मध्यम"
        },
        "farmer_info": {
            "symptoms": {
                "basic": "पानांवर तपकिरी ठिपके दिसतात"
            },
            "treatment": {
                "content": "मॅन्कोझेब फवारणी करा"
            },
            "cost_info": {
                "total": "₹1500 प्रति एकर"
            }
        }
    }

# Include routers if they exist
if prediction_router:
    app.include_router(prediction_router, prefix="/api", tags=["prediction"])
if health_router:
    app.include_router(health_router, prefix="/api", tags=["health"])
if diseases_router:
    app.include_router(diseases_router, prefix="/api", tags=["diseases"])

# Global exception handler
@app.exception_handler(Exception)
async def global_exception_handler(request: Request, exc: Exception):
    logger.error(f"Global exception: {exc}")
    return {
        "success": False,
        "error": "काहीतरी चूक झाली",
        "error_english": "Something went wrong"
    }

if __name__ == "__main__":
    logger.info("🌾 Starting ऊस एकरी १०० टन Application...")
    
    # Check if model exists, create dummy if not
    model_path = "models/sugarcane_disease_model.h5"
    if not os.path.exists(model_path):
        logger.info("Creating dummy model for testing...")
        try:
            import tensorflow as tf
            model = tf.keras.Sequential([
                tf.keras.layers.Input(shape=(224, 224, 3)),
                tf.keras.layers.GlobalAveragePooling2D(),
                tf.keras.layers.Dense(128, activation='relu'),
                tf.keras.layers.Dense(7, activation='softmax')
            ])
            model.compile(optimizer='adam', loss='categorical_crossentropy', metrics=['accuracy'])
            model.save(model_path)
            logger.info("✅ Dummy model created")
        except Exception as e:
            logger.warning(f"Could not create model: {e}")
    
    # Run the application
    uvicorn.run(
        "main:app",
        host="0.0.0.0",
        port=8000,
        reload=True,
        log_level="info"
    )
