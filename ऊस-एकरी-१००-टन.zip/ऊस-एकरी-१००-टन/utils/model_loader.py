"""
AI Model Loader - Professional Model Management System
Handles loading and initialization of the sugarcane disease detection model
"""

import os
import json
import logging
import tensorflow as tf
import numpy as np
from typing import Tuple, Optional, Dict, Any

logger = logging.getLogger(__name__)

class SugarcaneModelLoader:
    """Professional model loader for sugarcane disease detection"""
    
    def __init__(self, config):
        """Initialize model loader with configuration"""
        self.config = config
        self.model = None
        self.classes = []
        self.disease_solutions = {}
        self.class_mapping = {}
        self.model_metadata = {}
        
    def load_all_components(self) -> bool:
        """Load model, classes, and disease solutions"""
        try:
            logger.info("🔄 शुरुआत: ऊस रोग ओळख प्रणाली लोड करत आहे...")
            
            # Load class mapping and solutions
            if not self._load_disease_data():
                return False
                
            # Load AI model
            if not self._load_model():
                return False
                
            # Validate everything loaded correctly
            if not self._validate_components():
                return False
                
            logger.info("✅ यश: सर्व घटक यशस्वीरित्या लोड झाले!")
            logger.info(f"📊 एकूण रोग प्रकार: {len(self.classes)}")
            logger.info(f"💊 उपचार माहिती: {len(self.disease_solutions)} रोगांसाठी")
            
            return True
            
        except Exception as e:
            logger.error(f"❌ त्रुटी: मॉडेल लोडिंगमध्ये समस्या - {str(e)}")
            return False
    
    def _load_disease_data(self) -> bool:
        """Load disease classification and treatment data"""
        try:
            logger.info("📋 रोग वर्गीकरण माहिती लोड करत आहे...")
            
            # Load class mapping
            class_mapping_path = self.config.CLASS_MAPPING_PATH
            if not os.path.exists(class_mapping_path):
                logger.error(f"❌ फाइल सापडली नाही: {class_mapping_path}")
                return False
                
            with open(class_mapping_path, 'r', encoding='utf-8') as f:
                self.class_mapping = json.load(f)
                
            # Extract classes list
            self.classes = self.class_mapping.get('classes', [])
            if not self.classes:
                logger.error("❌ रोग वर्ग माहिती रिकामी आहे")
                return False
                
            logger.info(f"✅ {len(self.classes)} रोग प्रकार लोड झाले")
            
            # Load disease solutions
            logger.info("💊 उपचार माहिती लोड करत आहे...")
            solutions_path = self.config.DISEASE_SOLUTIONS_PATH
            
            if not os.path.exists(solutions_path):
                logger.warning(f"⚠️ उपचार फाइल सापडली नाही: {solutions_path}")
                self.disease_solutions = {}
                return True
                
            with open(solutions_path, 'r', encoding='utf-8') as f:
                self.disease_solutions = json.load(f)
                
            logger.info(f"✅ {len(self.disease_solutions)} रोगांचे उपचार लोड झाले")
            return True
            
        except Exception as e:
            logger.error(f"❌ डेटा लोडिंग त्रुटी: {str(e)}")
            return False
    
    def _load_model(self) -> bool:
        """Load the trained AI model"""
        try:
            logger.info("🧠 AI मॉडेल लोड करत आहे...")
            
            model_path = self.config.MODEL_PATH
            if not os.path.exists(model_path):
                logger.error(f"❌ मॉडेल फाइल सापडली नाही: {model_path}")
                return False
            
            # Suppress TensorFlow warnings for cleaner output
            os.environ['TF_CPP_MIN_LOG_LEVEL'] = '2'
            
            # Try loading the model
            logger.info(f"📂 मॉडेल लोड करत आहे: {os.path.basename(model_path)}")
            
            # Load model with error handling for different TensorFlow versions
            try:
                self.model = tf.keras.models.load_model(model_path, compile=False)
                logger.info("✅ मॉडेल यशस्वीरित्या लोड झाले")
                
            except Exception as load_error:
                logger.warning(f"⚠️ पूर्ण मॉडेल लोड अयशस्वी: {load_error}")
                
                # Try alternative loading with custom architecture
                logger.info("🔄 वैकल्पिक पद्धतीने मॉडेल लोड करत आहे...")
                self.model = self._create_alternative_model()
                
                if self.model is None:
                    return False
                    
            # Compile model for predictions
            self.model.compile(
                optimizer='adam',
                loss='categorical_crossentropy',
                metrics=['accuracy']
            )
            
            # Log model information
            logger.info(f"📐 मॉडेल इनपुट आकार: {self.model.input_shape}")
            logger.info(f"📊 मॉडेल आउटपुट आकार: {self.model.output_shape}")
            
            return True
            
        except Exception as e:
            logger.error(f"❌ मॉडेल लोडिंग त्रुटी: {str(e)}")
            return False
    
    def _create_alternative_model(self):
        """Create alternative model architecture if direct loading fails"""
        try:
            logger.info("🏗️ वैकल्पिक मॉडेल आर्किटेक्चर तयार करत आहे...")
            
            # Create MobileNetV2-based architecture (matches your utils.py)
            base_model = tf.keras.applications.MobileNetV2(
                input_shape=(self.config.IMAGE_SIZE, self.config.IMAGE_SIZE, 3),
                include_top=False,
                weights='imagenet'
            )
            
            base_model.trainable = False
            
            model = tf.keras.Sequential([
                base_model,
                tf.keras.layers.GlobalAveragePooling2D(),
                tf.keras.layers.Dropout(0.2),
                tf.keras.layers.Dense(len(self.classes), activation='softmax')
            ])
            
            logger.info("✅ वैकल्पिक मॉडेल तयार झाले")
            return model
            
        except Exception as e:
            logger.error(f"❌ वैकल्पिक मॉडेल त्रुटी: {str(e)}")
            return None
    
    def _validate_components(self) -> bool:
        """Validate all loaded components"""
        try:
            # Validate model
            if self.model is None:
                logger.error("❌ मॉडेल लोड नाही")
                return False
                
            # Validate classes
            if not self.classes:
                logger.error("❌ रोग वर्ग माहिती नाही")
                return False
                
            # Check model output matches classes
            expected_output = len(self.classes)
            actual_output = self.model.output_shape[-1]
            
            if actual_output != expected_output:
                logger.warning(f"⚠️ मॉडेल आउटपुट वेगळे: अपेक्षित {expected_output}, वास्तविक {actual_output}")
                
            logger.info("✅ सर्व घटकांचे प्रमाणीकरण पूर्ण")
            return True
            
        except Exception as e:
            logger.error(f"❌ प्रमाणीकरण त्रुटी: {str(e)}")
            return False
    
    def get_model_info(self) -> Dict[str, Any]:
        """Get comprehensive model information"""
        return {
            'model_loaded': self.model is not None,
            'total_classes': len(self.classes),
            'classes': self.classes,
            'solutions_available': len(self.disease_solutions),
            'input_shape': self.model.input_shape if self.model else None,
            'output_shape': self.model.output_shape if self.model else None,
            'model_type': 'MobileNetV2-based CNN',
            'status': 'तयार' if self.model else 'लोड नाही'
        }

# Global model loader instance
_model_loader = None

def get_model_loader(config=None):
    """Get global model loader instance"""
    global _model_loader
    if _model_loader is None and config:
        _model_loader = SugarcaneModelLoader(config)
    return _model_loader

def initialize_model_and_data(config=None):
    """Initialize model and data for the application"""
    if config is None:
        from flask import current_app
        config = current_app.config
    
    loader = get_model_loader(config)
    if loader:
        return loader.load_all_components()
    return False
