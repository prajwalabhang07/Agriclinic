"""
Advanced Image Processing for Sugarcane Disease Detection
Farmer-friendly error handling with Marathi messages
"""

import logging
import numpy as np
from PIL import Image, ImageEnhance, ImageFilter
from typing import Optional, Tuple, Dict, Any
import io

logger = logging.getLogger(__name__)

class FarmerFriendlyImageProcessor:
    """Professional image processor with farmer-friendly features"""
    
    def __init__(self, config):
        """Initialize image processor"""
        self.config = config
        self.target_size = (config.IMAGE_SIZE, config.IMAGE_SIZE)
        self.channels = config.IMAGE_CHANNELS
        
    def process_image_for_prediction(self, image_file) -> Optional[np.ndarray]:
        """
        Process uploaded image for AI prediction
        Returns preprocessed numpy array or None if processing fails
        """
        try:
            logger.info("📸 छायाचित्र प्रक्रिया सुरू करत आहे...")
            
            # Load and validate image
            image = self._load_and_validate_image(image_file)
            if image is None:
                return None
            
            # Enhance image quality
            enhanced_image = self._enhance_image_quality(image)
            
            # Resize for model
            resized_image = self._resize_image(enhanced_image)
            
            # Convert to model input format
            processed_array = self._prepare_for_model(resized_image)
            
            logger.info("✅ छायाचित्र प्रक्रिया पूर्ण झाली")
            logger.info(f"📊 अंतिम आकार: {processed_array.shape}")
            
            return processed_array
            
        except Exception as e:
            logger.error(f"❌ छायाचित्र प्रक्रिया त्रुटी: {str(e)}")
            return None
    
    def _load_and_validate_image(self, image_file) -> Optional[Image.Image]:
        """Load and validate uploaded image file"""
        try:
            # Handle different input types
            if hasattr(image_file, 'read'):
                # File-like object
                image_data = image_file.read()
                image = Image.open(io.BytesIO(image_data))
            else:
                # File path or PIL Image
                image = Image.open(image_file)
            
            logger.info(f"📂 मूळ छायाचित्र - आकार: {image.size}, मोड: {image.mode}")
            
            # Validate image
            validation_result = self._validate_image(image)
            if not validation_result['valid']:
                logger.error(f"❌ छायाचित्र अवैध: {validation_result['error_marathi']}")
                return None
            
            # Convert to RGB if necessary
            if image.mode != 'RGB':
                logger.info(f"🔄 रंग मोड बदलत आहे: {image.mode} → RGB")
                image = image.convert('RGB')
            
            return image
            
        except Exception as e:
            logger.error(f"❌ छायाचित्र लोड करण्यात त्रुटी: {str(e)}")
            return None
    
    def _validate_image(self, image: Image.Image) -> Dict[str, Any]:
        """Validate image for processing"""
        try:
            # Check image size (minimum requirements)
            min_size = 50
            if image.size[0] < min_size or image.size[1] < min_size:
                return {
                    'valid': False,
                    'error_marathi': f'छायाचित्र खूप लहान आहे (किमान {min_size}x{min_size} असावे)',
                    'error_english': f'Image too small (minimum {min_size}x{min_size} required)'
                }
            
            # Check image aspect ratio (should be reasonable)
            width, height = image.size
            aspect_ratio = width / height
            
            if aspect_ratio > 5 or aspect_ratio < 0.2:
                return {
                    'valid': False,
                    'error_marathi': 'छायाचित्राचे प्रमाण योग्य नाही (खूप लांब किंवा खूप उंच)',
                    'error_english': 'Invalid image aspect ratio'
                }
            
            # Check if image has content (not just blank)
            image_array = np.array(image)
            if np.std(image_array) < 10:  # Very low variation means likely blank
                return {
                    'valid': False,
                    'error_marathi': 'छायाचित्र रिकामे किंवा एकसारखे दिसते',
                    'error_english': 'Image appears to be blank or uniform'
                }
            
            return {
                'valid': True,
                'width': width,
                'height': height,
                'aspect_ratio': aspect_ratio
            }
            
        except Exception as e:
            return {
                'valid': False,
                'error_marathi': f'छायाचित्र तपासणीत त्रुटी: {str(e)}',
                'error_english': f'Image validation error: {str(e)}'
            }
    
    def _enhance_image_quality(self, image: Image.Image) -> Image.Image:
        """Enhance image quality for better AI recognition"""
        try:
            logger.info("✨ छायाचित्र गुणवत्ता सुधारत आहे...")
            
            # Apply gentle enhancements
            enhanced = image
            
            # Slight sharpening for better leaf detail
            enhancer = ImageEnhance.Sharpness(enhanced)
            enhanced = enhancer.enhance(1.1)
            
            # Slight contrast enhancement
            enhancer = ImageEnhance.Contrast(enhanced)
            enhanced = enhancer.enhance(1.05)
            
            # Color balance (slight saturation boost for better leaf color)
            enhancer = ImageEnhance.Color(enhanced)
            enhanced = enhancer.enhance(1.1)
            
            return enhanced
            
        except Exception as e:
            logger.warning(f"⚠️ गुणवत्ता सुधारणा त्रुटी: {str(e)}")
            return image  # Return original if enhancement fails
    
    def _resize_image(self, image: Image.Image) -> Image.Image:
        """Resize image to model requirements"""
        try:
            logger.info(f"📏 आकार बदलत आहे: {image.size} → {self.target_size}")
            
            # Use high-quality resampling
            resized = image.resize(self.target_size, Image.Resampling.LANCZOS)
            
            return resized
            
        except Exception as e:
            logger.error(f"❌ आकार बदलण्यात त्रुटी: {str(e)}")
            # Fallback to simple resize
            return image.resize(self.target_size)
    
    def _prepare_for_model(self, image: Image.Image) -> np.ndarray:
        """Convert PIL image to model input format"""
        try:
            # Convert to numpy array
            img_array = np.array(image, dtype=np.float32)
            
            logger.info(f"🔢 अॅरे रूपांतर - आकार: {img_array.shape}")
            
            # Normalize pixel values based on model requirements
            # Standard normalization: [0, 255] → [0, 1]
            img_array = img_array / 255.0
            
            logger.info(f"📊 सामान्यीकरण - परास: [{np.min(img_array):.3f}, {np.max(img_array):.3f}]")
            
            # Add batch dimension
            img_array = np.expand_dims(img_array, axis=0)
            
            # Validate final shape
            expected_shape = (1, self.target_size[0], self.target_size[1], self.channels)
            if img_array.shape != expected_shape:
                raise ValueError(f"अपेक्षित आकार {expected_shape}, मिळाले {img_array.shape}")
            
            # Final validation
            if np.isnan(img_array).any():
                raise ValueError("NaN मूल्ये सापडली")
            
            if not np.isfinite(img_array).all():
                raise ValueError("अवैध मूल्ये सापडली")
            
            return img_array
            
        except Exception as e:
            logger.error(f"❌ मॉडेल तयारी त्रुटी: {str(e)}")
            raise
    
    def get_image_info(self, image: Image.Image) -> Dict[str, Any]:
        """Get comprehensive image information"""
        try:
            img_array = np.array(image)
            
            return {
                'size': image.size,
                'mode': image.mode,
                'format': image.format,
                'width': image.size[0],
                'height': image.size[1],
                'channels': img_array.shape[2] if len(img_array.shape) > 2 else 1,
                'data_type': str(img_array.dtype),
                'size_bytes': img_array.nbytes,
                'min_value': int(np.min(img_array)),
                'max_value': int(np.max(img_array)),
                'mean_value': float(np.mean(img_array)),
                'status_marathi': 'छायाचित्र तयार',
                'status_english': 'Image ready'
            }
            
        except Exception as e:
            return {'error': str(e)}

# Global image processor instance
_image_processor = None

def get_image_processor(config=None):
    """Get global image processor instance"""
    global _image_processor
    if _image_processor is None and config:
        _image_processor = FarmerFriendlyImageProcessor(config)
    return _image_processor

def process_farmer_image(image_file, config=None):
    """Process image uploaded by farmer"""
    if config is None:
        from flask import current_app
        config = current_app.config
    
    processor = get_image_processor(config)
    if processor:
        return processor.process_image_for_prediction(image_file)
    return None
