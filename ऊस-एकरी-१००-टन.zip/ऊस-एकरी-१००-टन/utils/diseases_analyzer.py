"""
Advanced Disease Analysis Engine
Professional AI-powered diagnosis with farmer-friendly explanations
"""

import logging
import numpy as np
from typing import Dict, Any, Optional, List
from datetime import datetime
import json

logger = logging.getLogger(__name__)

class AdvancedDiseaseAnalyzer:
    """Professional disease analyzer with comprehensive diagnosis"""
    
    def __init__(self, model_loader, config):
        """Initialize disease analyzer"""
        self.model_loader = model_loader
        self.config = config
        self.confidence_thresholds = {
            'high': 0.80,      # उच्च विश्वास
            'medium': 0.60,    # मध्यम विश्वास
            'low': 0.40        # कमी विश्वास
        }
        
    def analyze_disease(self, processed_image: np.ndarray, farmer_context: Dict = None) -> Dict[str, Any]:
        """
        Perform comprehensive disease analysis
        Returns detailed diagnosis with farmer-friendly explanations
        """
        try:
            logger.info("🔬 रोग विश्लेषण सुरू करत आहे...")
            
            # Basic context setup
            if farmer_context is None:
                farmer_context = {}
            
            # Perform AI prediction
            prediction_result = self._perform_ai_prediction(processed_image)
            if not prediction_result['success']:
                return prediction_result
            
            # Analyze confidence levels
            confidence_analysis = self._analyze_confidence(
                prediction_result['predictions'], 
                prediction_result['predicted_class']
            )
            
            # Get disease information
            disease_info = self._get_comprehensive_disease_info(
                prediction_result['predicted_class'],
                prediction_result['confidence'],
                farmer_context
            )
            
            # Generate recommendations
            recommendations = self._generate_farmer_recommendations(
                prediction_result['predicted_class'],
                prediction_result['confidence'],
                farmer_context
            )
            
            # Calculate costs and timeline
            cost_analysis = self._calculate_treatment_costs(
                prediction_result['predicted_class'],
                farmer_context.get('farm_size', 1.0)
            )
            
            # Prepare comprehensive result
            result = {
                'success': True,
                'timestamp': datetime.now().isoformat(),
                
                # Primary prediction
                'disease_name_english': prediction_result['predicted_class'],
                'disease_name_marathi': disease_info.get('marathi_name', 'अज्ञात रोग'),
                'confidence': round(prediction_result['confidence'] * 100, 1),
                'confidence_level_marathi': confidence_analysis['level_marathi'],
                'confidence_level_english': confidence_analysis['level_english'],
                
                # Disease information
                'symptoms': disease_info.get('symptoms', 'माहिती उपलब्ध नाही'),
                'detailed_symptoms': disease_info.get('detailed_symptoms', []),
                'scientific_name': disease_info.get('scientific_name', 'माहिती नाही'),
                
                # Treatment and recommendations
                'solution': disease_info.get('solution', 'कृषी तज्ञांचा सल्ला घ्या'),
                'prevention': disease_info.get('prevention', 'सामान्य काळजी घ्या'),
                'immediate_actions': recommendations['immediate_actions'],
                'long_term_care': recommendations['long_term_care'],
                
                # Cost and timeline
                'cost_estimate': cost_analysis['total_cost_marathi'],
                'cost_breakdown': cost_analysis['breakdown'],
                'recovery_time': disease_info.get('recovery_time', 'माहिती नाही'),
                'recovery_timeline': cost_analysis['timeline'],
                
                # Additional analysis
                'severity_level': confidence_analysis['severity'],
                'urgency_required': confidence_analysis['urgent'],
                'expert_consultation': confidence_analysis['expert_needed'],
                'alternative_diagnoses': self._get_alternative_diagnoses(prediction_result['predictions']),
                
                # Farmer support
                'next_steps_marathi': recommendations['next_steps'],
                'warning_signs': recommendations['warning_signs'],
                'success_indicators': recommendations['success_indicators'],
                
                # Technical details (for logging/debugging)
                'model_info': {
                    'confidence_raw': prediction_result['confidence'],
                    'top_3_predictions': prediction_result.get('top_predictions', []),
                    'processing_time': prediction_result.get('processing_time', 0)
                }
            }
            
            logger.info(f"✅ विश्लेषण पूर्ण: {result['disease_name_marathi']} ({result['confidence']}%)")
            return result
            
        except Exception as e:
            logger.error(f"❌ रोग विश्लेषण त्रुटी: {str(e)}")
            return {
                'success': False,
                'error_marathi': f'रोग ओळखण्यात त्रुटी: {str(e)}',
                'error_english': f'Disease analysis failed: {str(e)}',
                'timestamp': datetime.now().isoformat()
            }
    
    def _perform_ai_prediction(self, processed_image: np.ndarray) -> Dict[str, Any]:
        """Perform AI model prediction"""
        try:
            if self.model_loader.model is None:
                return {
                    'success': False,
                    'error_marathi': 'AI मॉडेल उपलब्ध नाही',
                    'error_english': 'AI model not available'
                }
            
            start_time = datetime.now()
            
            # Make prediction
            logger.info("🧠 AI मॉडेल चालवत आहे...")
            predictions = self.model_loader.model.predict(processed_image, verbose=0)[0]
            
            # Get prediction results
            predicted_class_idx = np.argmax(predictions)
            confidence = float(predictions[predicted_class_idx])
            
            # Get class name
            if predicted_class_idx < len(self.model_loader.classes):
                predicted_class = self.model_loader.classes[predicted_class_idx]
            else:
                predicted_class = "Unknown"
            
            # Calculate processing time
            processing_time = (datetime.now() - start_time).total_seconds()
            
            # Get top 3 predictions for reference
            top_3_indices = np.argsort(predictions)[-3:][::-1]
            top_predictions = []
            for idx in top_3_indices:
                if idx < len(self.model_loader.classes):
                    top_predictions.append({
                        'class': self.model_loader.classes[idx],
                        'confidence': float(predictions[idx])
                    })
            
            logger.info(f"🎯 मुख्य निदान: {predicted_class} ({confidence:.1%})")
            
            return {
                'success': True,
                'predicted_class': predicted_class,
                'confidence': confidence,
                'predictions': predictions,
                'top_predictions': top_predictions,
                'processing_time': processing_time
            }
            
        except Exception as e:
            logger.error(f"❌ AI अंदाज त्रुटी: {str(e)}")
            return {
                'success': False,
                'error_marathi': f'AI अंदाज अयशस्वी: {str(e)}',
                'error_english': f'AI prediction failed: {str(e)}'
            }
    
    def _analyze_confidence(self, predictions: np.ndarray, predicted_class: str) -> Dict[str, Any]:
        """Analyze prediction confidence and determine reliability"""
        try:
            max_confidence = float(np.max(predictions))
            
            # Determine confidence level
            if max_confidence >= self.confidence_thresholds['high']:
                level_marathi = 'उच्च विश्वास'
                level_english = 'High confidence'
                severity = 'गंभीर' if predicted_class != 'Healthy' else 'निरोगी'
                urgent = predicted_class in ['RedRot', 'Sett Rot', 'Grassy shoot']
                expert_needed = urgent
                
            elif max_confidence >= self.confidence_thresholds['medium']:
                level_marathi = 'मध्यम विश्वास'
                level_english = 'Medium confidence'
                severity = 'मध्यम'
                urgent = predicted_class in ['RedRot', 'Sett Rot']
                expert_needed = predicted_class in ['RedRot', 'Sett Rot', 'Grassy shoot']
                
            else:
                level_marathi = 'कमी विश्वास'
                level_english = 'Low confidence'
                severity = 'अनिश्चित'
                urgent = False
                expert_needed = True  # Always recommend expert for low confidence
            
            return {
                'level_marathi': level_marathi,
                'level_english': level_english,
                'severity': severity,
                'urgent': urgent,
                'expert_needed': expert_needed,
                'confidence_score': max_confidence
            }
            
        except Exception as e:
            logger.error(f"❌ विश्वास विश्लेषण त्रुटी: {str(e)}")
            return {
                'level_marathi': 'अनिश्चित',
                'level_english': 'Uncertain',
                'severity': 'अज्ञात',
                'urgent': True,  # Default to urgent for safety
                'expert_needed': True
            }
    
    def _get_comprehensive_disease_info(self, disease_class: str, confidence: float, farmer_context: Dict) -> Dict[str, Any]:
        """Get comprehensive disease information"""
        try:
            # Get basic disease info from solutions database
            disease_data = self.model_loader.disease_solutions.get(disease_class, {})
            
            # Get Marathi name from class mapping
            marathi_name = self.model_loader.class_mapping.get('marathinames', {}).get(disease_class, disease_class)
            
            # Get scientific name
            scientific_name = self.model_loader.class_mapping.get('scientificnames', {}).get(disease_class, 'माहिती नाही')
            
            # Enhance with contextual information
            enhanced_info = {
                'marathi_name': marathi_name,
                'scientific_name': scientific_name,
                'symptoms': disease_data.get('symptoms', 'लक्षणे उपलब्ध नाहीत'),
                'detailed_symptoms': disease_data.get('detailedsymptoms', 'तपशीलवार माहिती नाही'),
                'solution': disease_data.get('solution', 'कृषी तज्ञांचा सल्ला घ्या'),
                'prevention': disease_data.get('prevention', 'सामान्य प्रतिबंधक उपाय करा'),
                'recovery_time': disease_data.get('recoverytime', 'माहिती उपलब्ध नाही'),
                'cost_estimate': disease_data.get('costestimate', 'खर्चाचा अंदाज उपलब्ध नाही'),
                'emergency_protocol': disease_data.get('emergencyprotocol', False),
                'organic_solutions': disease_data.get('organicsolutions', [])
            }
            
            return enhanced_info
            
        except Exception as e:
            logger.error(f"❌ रोग माहिती त्रुटी: {str(e)}")
            return {
                'marathi_name': 'अज्ञात रोग',
                'symptoms': 'माहिती उपलब्ध नाही',
                'solution': 'तत्काळ कृषी तज्ञांचा सल्ला घ्या'
            }
    
    def _generate_farmer_recommendations(self, disease_class: str, confidence: float, farmer_context: Dict) -> Dict[str, Any]:
        """Generate farmer-specific recommendations"""
        try:
            recommendations = {
                'immediate_actions': [],
                'long_term_care': [],
                'next_steps': [],
                'warning_signs': [],
                'success_indicators': []
            }
            
            # Immediate actions based on disease type
            if disease_class == 'Healthy':
                recommendations['immediate_actions'] = [
                    'सध्याची चांगली काळजी चालू ठेवा',
                    'नियमित तपासणी करत राहा',
                    'प्रतिबंधक फवारणी करा'
                ]
                
            elif disease_class in ['RedRot', 'Sett Rot']:
                recommendations['immediate_actions'] = [
                    'तत्काळ संक्रमित भाग काढून टाका',
                    '24 तासांत कृषी तज्ञांशी संपर्क साधा',
                    'शेजारील पिकांचे संरक्षण करा',
                    'जळजळीत औषध फवारा'
                ]
                
            else:
                recommendations['immediate_actions'] = [
                    'प्रभावित भागाचे फोटो घ्या',
                    'नियंत्रणासाठी फवारणी करा',
                    'पुढील 3-5 दिवसांत प्रगती तपासा'
                ]
            
            # Next steps for farmer
            recommendations['next_steps'] = [
                'दररोज पिकाची तपासणी करा',
                'हवामान बदलाकडे लक्ष द्या',
                'उपचारानंतरचे परिणाम नोंदवा',
                'शंका असल्यास पुन्हा फोटो घ्या'
            ]
            
            # Warning signs to watch for
            recommendations['warning_signs'] = [
                'लक्षणे वाढत असल्यास',
                'नवीन भागात पसरत असल्यास', 
                'पाने जळून गेल्यास',
                'उत्पादनात घट दिसल्यास'
            ]
            
            # Success indicators
            recommendations['success_indicators'] = [
                'नवीन हिरवी पाने येणे',
                'जुनी लक्षणे कमी होणे',
                'पिकाची वाढ सुधारणे',
                'रंग परत येणे'
            ]
            
            return recommendations
            
        except Exception as e:
            logger.error(f"❌ शिफारस त्रुटी: {str(e)}")
            return {
                'immediate_actions': ['तत्काळ कृषी तज्ञांचा सल्ला घ्या'],
                'next_steps': ['नियमित तपासणी करा'],
                'warning_signs': ['कोणतेही नवे बदल दिसल्यास'],
                'success_indicators': ['सुधारणेची चिन्हे दिसेपर्यंत']
            }
    
    def _calculate_treatment_costs(self, disease_class: str, farm_size: float = 1.0) -> Dict[str, Any]:
        """Calculate treatment costs in farmer-friendly format"""
        try:
            # Base costs per acre for different diseases (in Rupees)
            base_costs = {
                'RedRot': {'medicine': 1200, 'labor': 800, 'follow_up': 400},
                'Brown Spot': {'medicine': 400, 'labor': 200, 'follow_up': 100},
                'Rust': {'medicine': 350, 'labor': 150, 'follow_up': 100},
                'Yellow Leaf': {'medicine': 500, 'labor': 300, 'follow_up': 200},
                'Banded Chlorosis': {'medicine': 600, 'labor': 400, 'follow_up': 200},
                'Healthy': {'medicine': 0, 'labor': 0, 'follow_up': 100},
                'Default': {'medicine': 500, 'labor': 300, 'follow_up': 200}
            }
            
            costs = base_costs.get(disease_class, base_costs['Default'])
            
            # Calculate total for farm size
            medicine_cost = int(costs['medicine'] * farm_size)
            labor_cost = int(costs['labor'] * farm_size)
            follow_up_cost = int(costs['follow_up'] * farm_size)
            total_cost = medicine_cost + labor_cost + follow_up_cost
            
            return {
                'total_cost_marathi': f'एकूण खर्च: ₹{total_cost:,}',
                'total_cost_number': total_cost,
                'breakdown': {
                    'medicine_marathi': f'औषध: ₹{medicine_cost:,}',
                    'labor_marathi': f'मजुरी: ₹{labor_cost:,}',
                    'follow_up_marathi': f'पाठपुरावा: ₹{follow_up_cost:,}'
                },
                'timeline': {
                    'immediate': 'पहिले 3 दिवस',
                    'follow_up': '1-2 आठवडे',
                    'monitoring': '1 महिना'
                },
                'per_acre': f'प्रति एकर: ₹{total_cost//max(1, int(farm_size)):,}'
            }
            
        except Exception as e:
            logger.error(f"❌ खर्च गणना त्रुटी: {str(e)}")
            return {
                'total_cost_marathi': 'खर्चाचा अंदाज उपलब्ध नाही',
                'breakdown': {},
                'timeline': {'immediate': 'तत्काळ', 'follow_up': 'पुढील आठवड्यात'}
            }
    
    def _get_alternative_diagnoses(self, predictions: np.ndarray) -> List[Dict]:
        """Get alternative possible diagnoses"""
        try:
            # Get top 3 predictions
            top_3_indices = np.argsort(predictions)[-3:][::-1]
            alternatives = []
            
            for i, idx in enumerate(top_3_indices[1:]):  # Skip the top prediction
                if idx < len(self.model_loader.classes):
                    class_name = self.model_loader.classes[idx]
                    marathi_name = self.model_loader.class_mapping.get('marathinames', {}).get(class_name, class_name)
                    
                    alternatives.append({
                        'rank': i + 2,
                        'disease_english': class_name,
                        'disease_marathi': marathi_name,
                        'confidence': round(float(predictions[idx]) * 100, 1),
                        'note_marathi': 'वैकल्पिक शक्यता' if i == 0 else 'कमी शक्यता'
                    })
            
            return alternatives
            
        except Exception as e:
            logger.error(f"❌ वैकल्पिक निदान त्रुटी: {str(e)}")
            return []

# Global disease analyzer instance
_disease_analyzer = None

def get_disease_analyzer(model_loader=None, config=None):
    """Get global disease analyzer instance"""
    global _disease_analyzer
    if _disease_analyzer is None and model_loader and config:
        _disease_analyzer = AdvancedDiseaseAnalyzer(model_loader, config)
    return _disease_analyzer

def analyze_farmer_image(processed_image, farmer_context=None, model_loader=None, config=None):
    """Analyze processed image for farmer"""
    if config is None:
        from flask import current_app
        config = current_app.config
    
    analyzer = get_disease_analyzer(model_loader, config)
    if analyzer:
        return analyzer.analyze_disease(processed_image, farmer_context)
    return {'success': False, 'error_marathi': 'विश्लेषक उपलब्ध नाही'}
